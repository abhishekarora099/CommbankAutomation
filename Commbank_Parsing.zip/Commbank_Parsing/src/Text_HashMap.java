import java.io.*;
import java.util.*;

class Text_HashMap {
	static int count=0;
	final static String filePath = "./File/q1.test_data";
	public static void main(String[] args)
	{
		try{
			Map<String, String> mapFromFile = HashMapFromTextFile();
			System.out.println("\n\nNumber of transactions are " +count);
			
			for (Map.Entry<String, String> entry : mapFromFile.entrySet()) {
				System.out.println(entry.getKey() + " : " + entry.getValue());
			}
		}
		catch(Exception e){
			
		}
		
	}

	public static Map<String, String> HashMapFromTextFile() throws Exception
	{
		Map<String, String> map = new HashMap<String, String>();
		BufferedReader br = null;

		try {
				File file = new File(filePath);
				br = new BufferedReader(new FileReader(file));
				String line = "";

			while ((line = br.readLine()) != null) 
			{
				String[] parts = line.split("\\[",0);
				count++;
				String name = parts[0].trim();
				String number = parts[1].trim();
				
				if (!name.equals("") && !number.equals("") && !name.equals("smh_seg_id_version"))
					map.put(name, number);
				
						
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {

			if (br != null) {
				try {
					br.close();
				}
				catch (Exception e) {
					
				};
			}
		}

		return map;
	}
}